package com.example.DoAnTotNghiep_MiniatureCrafts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoAnTotNghiepMiniatureCraftsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoAnTotNghiepMiniatureCraftsApplication.class, args);
	}

}
