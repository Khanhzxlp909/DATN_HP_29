package com.example.DoAnTotNghiep_MiniatureCrafts.Entity;

public enum ERole {
    USER,
    MODERATOR,
    ADMIN
}
