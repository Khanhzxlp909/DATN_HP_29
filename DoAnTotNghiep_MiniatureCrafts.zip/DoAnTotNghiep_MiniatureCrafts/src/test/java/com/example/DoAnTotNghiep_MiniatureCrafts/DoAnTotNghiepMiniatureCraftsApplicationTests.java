package com.example.DoAnTotNghiep_MiniatureCrafts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoAnTotNghiepMiniatureCraftsApplicationTests {

	@Test
	void contextLoads() {
	}

}
